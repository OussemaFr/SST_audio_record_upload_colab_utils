from distutils.core import setup

setup(
    name='audio_record_upload',
    version='0.1',
    packages=['audio_record_upload', ],
    install_requires=[
        'pydub',
        'librosa'
    ]
)
